import os

os.system('ipconfig')

eval("print('hello woniu')")

result = os.popen('ipconfig').read()
print(result)
