import base64

def encode():
    source = 'Man'
    print(base64.b64encode(source.encode()))


def decode():
    source = 'TWFu'
    print(base64.b64decode(source).decode())


if __name__ == '__main__':
    # encode()
    decode()